#!/bin/bash

# Script para iniciar o MultiVozes
MULTIVOZES_DIR="/home/usuario/multivozes_br_engine"  # Ajuste para seu caminho
LOG_FILE="/var/www/html/ytgenerator/writable/logs/multivozes.log"

cd $MULTIVOZES_DIR

# Ativar ambiente virtual e iniciar
source venv/bin/activate
nohup python main.py > $LOG_FILE 2>&1 &

echo "✅ MultiVozes iniciado em background"
echo "📝 Log em: $LOG_FILE"
echo "🌐 API em: http://localhost:5050"
