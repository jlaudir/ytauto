#!/bin/bash

# ============================================
# Instalação Manual do Multivozes BR Engine
# ============================================

INSTALL_DIR="/opt/multivozes_br_engine"
PORT=5050

echo "🚀 Instalando Multivozes BR Engine..."

# Criar diretório
sudo mkdir -p $INSTALL_DIR
cd $INSTALL_DIR

# Criar requirements.txt
sudo tee $INSTALL_DIR/requirements.txt > /dev/null << 'EOF'
fastapi==0.104.1
uvicorn==0.24.0
python-multipart==0.0.6
pydantic==2.5.0
python-dotenv==1.0.0
edge-tts==6.1.9
EOF

# Criar app.py principal
sudo tee $INSTALL_DIR/app.py > /dev/null << 'EOF'
import os
import uuid
from fastapi import FastAPI, HTTPException, Header
from fastapi.responses import FileResponse
from pydantic import BaseModel
from dotenv import load_dotenv
import edge_tts

load_dotenv()

app = FastAPI(title="Multivozes BR Engine")

API_KEY = os.getenv("API_KEY", "")
PORT = int(os.getenv("PORT", 5050))

class TTSRequest(BaseModel):
    input: str
    voice: str = "pt-BR-AntonioNeural"

def verify_api_key(authorization: str = Header(None)):
    if not API_KEY:
        return True
    if not authorization:
        raise HTTPException(status_code=401, detail="Chave de API ausente. Use: Authorization: Bearer SUA_CHAVE")
    parts = authorization.split()
    if len(parts) != 2 or parts[0].lower() != "bearer":
        raise HTTPException(status_code=401, detail="Formato inválido. Use: Bearer <chave>")
    if parts[1] != API_KEY:
        raise HTTPException(status_code=401, detail="Chave de API inválida")
    return True

@app.get("/")
def root():
    return {"message": "Multivozes BR Engine", "status": "running", "port": PORT}

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/v1/audio/speech")
async def text_to_speech(request: TTSRequest, authorization: str = Header(None)):
    verify_api_key(authorization)
    
    output_file = f"/tmp/speech_{uuid.uuid4().hex}.mp3"
    
    try:
        communicate = edge_tts.Communicate(request.input, request.voice)
        await communicate.save(output_file)
        return FileResponse(output_file, media_type="audio/mpeg", filename="speech.mp3")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", 5050))
    uvicorn.run(app, host=host, port=port)
EOF

# Criar ambiente virtual
echo "🐍 Criando ambiente virtual..."
sudo apt install -y python3-venv
sudo python3 -m venv venv

# Instalar dependências
echo "📚 Instalando dependências..."
sudo bash -c "source venv/bin/activate && pip install --upgrade pip && pip install -r requirements.txt"

# Gerar API Key
API_KEY=$(openssl rand -hex 32)

# Criar .env
sudo tee $INSTALL_DIR/.env > /dev/null << EOF
API_KEY=$API_KEY
PORT=$PORT
HOST=0.0.0.0
EOF

# Criar script de inicialização
sudo tee /usr/local/bin/multivozes-start > /dev/null << EOF
#!/bin/bash
cd $INSTALL_DIR
source venv/bin/activate
python app.py
EOF

sudo chmod +x /usr/local/bin/multivozes-start

# Criar serviço systemd
sudo tee /etc/systemd/system/multivozes.service > /dev/null << EOF
[Unit]
Description=Multivozes BR Engine
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/venv/bin/python $INSTALL_DIR/app.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Iniciar serviço
sudo systemctl daemon-reload
sudo systemctl enable multivozes
sudo systemctl start multivozes

# Aguardar
sleep 3

# Testar
echo ""
echo "✅ INSTALAÇÃO CONCLUÍDA!"
echo "==================================="
echo "🔑 API KEY: $API_KEY"
echo "📍 URL: http://localhost:$PORT"
echo ""
echo "📖 Comandos:"
echo "  sudo systemctl start multivozes"
echo "  sudo systemctl stop multivozes"
echo "  sudo systemctl status multivozes"
echo ""
echo "🧪 Testar API:"
echo "  curl -X POST http://localhost:$PORT/v1/audio/speech \\"
echo "    -H 'Authorization: Bearer $API_KEY' \\"
echo "    -H 'Content-Type: application/json' \\"
echo "    -d '{\"input\":\"Olá mundo\",\"voice\":\"pt-BR-AntonioNeural\"}' \\"
echo "    --output audio.mp3"
echo "==================================="
