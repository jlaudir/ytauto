echo "=== Diagnóstico Multivozes ==="
echo "1. Chave API:"
sudo grep API_KEY /opt/multivozes_br_engine/.env
echo ""
echo "2. Teste com curl detalhado:"
API_KEY=$(sudo grep API_KEY /opt/multivozes_br_engine/.env | cut -d '=' -f2)
curl -X POST http://localhost:5050/v1/audio/speech \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"input":"Oi","voice":"pt-BR-AntonioNeural"}' \
  -w "\nHTTP Code: %{http_code}\n"
echo ""
echo "3. Logs do serviço:"
sudo journalctl -u multivozes --since "1 minute ago" --no-pager
