#/bin/sh
curl -X POST http://localhost:5050/v1/audio/speech -H "TDgiSlWlF1GRRHW4ix4ziNuc9UmX/l5F7xvg+vwcw1M="
